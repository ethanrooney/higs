#ifndef AllParticles_H
#define AllParticles_H 1

class AllParticles
{
  private:

  protected:

  public:

    AllParticles();
    ~AllParticles();
    static void ConstructAllParticles(void);
    static void PrintParticleTable(void);

}; //END of class AllParticles

#endif
